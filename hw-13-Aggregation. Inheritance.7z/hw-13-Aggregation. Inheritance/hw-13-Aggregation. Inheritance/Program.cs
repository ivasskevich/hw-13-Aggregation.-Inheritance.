﻿interface IBuildingPart
{
    bool IsConstructed { get; set; }
}

interface IConstructionWorker
{
    void Construct(House house);
}

class Foundation : IBuildingPart
{
    public bool IsConstructed { get; set; }
}

class Structure : IBuildingPart
{
    public bool IsConstructed { get; set; }
}

class Opening : IBuildingPart
{
    public bool IsConstructed { get; set; }
}

class Roofing : IBuildingPart
{
    public bool IsConstructed { get; set; }
}

class House
{
    public IBuildingPart Foundation { get; private set; }
    public List<IBuildingPart> Walls { get; private set; }
    public List<IBuildingPart> Windows { get; private set; }
    public IBuildingPart Door { get; private set; }
    public IBuildingPart Roof { get; private set; }

    public House()
    {
        Foundation = new Foundation();
        Walls = new List<IBuildingPart> { new Structure(), new Structure(), new Structure(), new Structure() };
        Windows = new List<IBuildingPart> { new Opening(), new Opening(), new Opening(), new Opening() };
        Door = new Opening();
        Roof = new Roofing();
    }
}

class Worker : IConstructionWorker
{
    public void Construct(House house)
    {
        if (!house.Foundation.IsConstructed)
        {
            house.Foundation.IsConstructed = true;
            Console.WriteLine("Foundation completed");
        }
        else
        {
            foreach (var wall in house.Walls)
            {
                if (!wall.IsConstructed)
                {
                    wall.IsConstructed = true;
                    Console.WriteLine("Wall completed");
                    return;
                }
            }

            if (!house.Door.IsConstructed)
            {
                house.Door.IsConstructed = true;
                Console.WriteLine("Door installed");
            }
            else
            {
                foreach (var window in house.Windows)
                {
                    if (!window.IsConstructed)
                    {
                        window.IsConstructed = true;
                        Console.WriteLine("Window installed");
                        return;
                    }
                }

                if (!house.Roof.IsConstructed)
                {
                    house.Roof.IsConstructed = true;
                    Console.WriteLine("Roof completed");
                }
            }
        }
    }
}

class Supervisor : IConstructionWorker
{
    public void Construct(House house)
    {
        int completedParts = 0;

        if (house.Foundation.IsConstructed) completedParts++;
        completedParts += house.Walls.Count(wall => wall.IsConstructed);
        completedParts += house.Windows.Count(window => window.IsConstructed);
        if (house.Door.IsConstructed) completedParts++;
        if (house.Roof.IsConstructed) completedParts++;

        Console.WriteLine($"Report: {completedParts} parts out of 11 completed");
    }
}

class ConstructionTeam
{
    private readonly List<IConstructionWorker> _workers;
    private readonly House _house;

    public ConstructionTeam(List<IConstructionWorker> workers, House house)
    {
        _workers = workers;
        _house = house;
    }

    public void StartBuilding()
    {
        bool isFinished = false;

        while (!isFinished)
        {
            foreach (var worker in _workers)
            {
                worker.Construct(_house);

                isFinished = IsHouseComplete(_house);
                if (isFinished) break;
            }
        }

        Console.WriteLine("House fully built!");
    }

    private bool IsHouseComplete(House house)
    {
        return house.Foundation.IsConstructed &&
               house.Walls.TrueForAll(wall => wall.IsConstructed) &&
               house.Windows.TrueForAll(window => window.IsConstructed) &&
               house.Door.IsConstructed &&
               house.Roof.IsConstructed;
    }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        House house = new House();
        List<IConstructionWorker> workers = new List<IConstructionWorker> { new Worker(), new Worker(), new Worker(), new Supervisor() };
        ConstructionTeam team = new ConstructionTeam(workers, house);
        team.StartBuilding();
    }
}
